#!/usr/bin/env bash

function ask_guess {
  echo "How many files are in the current directory?"
  read guess
}

actual_count=$(ls -1 | wc -l)

ask_guess

while [[ $guess -ne $actual_count ]]
do
  if [[ $guess -lt $actual_count ]]
  then
    echo "Too low!"
  else
    echo "Too high!"
  fi
  ask_guess
done

echo "Congratulations! You guessed it right. There are $actual_count files."
